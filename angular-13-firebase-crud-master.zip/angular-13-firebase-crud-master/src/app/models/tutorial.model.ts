export class Tutorial {
  key?: string | null;
  title?: string;
  description?: string;
  published?: boolean;
}